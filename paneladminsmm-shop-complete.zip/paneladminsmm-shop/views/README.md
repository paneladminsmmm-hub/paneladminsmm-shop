# Views
The current Express app renders its small server-side HTML pages from reusable helpers in `server.js`.
This folder is kept for future template separation (EJS/Pug) and is included so the project structure is complete.
