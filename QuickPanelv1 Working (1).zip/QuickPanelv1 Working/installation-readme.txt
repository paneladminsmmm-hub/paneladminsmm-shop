Thanks For Your Order With OwnSMMPanel.in

DEFULT LOGIN FOR SUPER ADMIN:
USER - adminac
PASS - 12345678

How To Install This Script?

STEP 1 : UPLOAD OSPQUICKPANEL.zip ON Your [ public_html ]
STEP 2 : EXTRACT OSPQUICKPANEL.zip ON Your [ public_html ]
STEP 3 : Thare You Can Se 2 Folders a) UPLOAD. b) DATABASE.
Open UPLOAD Folder and Select All Files And Move To [ public_html ]

Imp : Must Show Hidden Files (dotfiles) From Your File Manager in Top Right Side Settings.

STEP 4 : Create Database.

How To Create Database ?

Set Up: Setting up your first database with MySQL Database Wizard in cPanel

To setup a database:
1) Click on MySQL Database Wizard under Databases in cPanel.
2) In the New Database text box, enter a name for the database. 
When ready, click Next Step.
3) In the Username text box, enter a name for the user who you wish to allow to manage the database.
4) Enter and confirm the new password in the appropriate text boxes.
5) When ready, click Create User.
6) On the next page, you can assign privileges for the user to the database. Select the checkboxes that correspond to the privileges that you want to grant the user, or select All Privileges.

When ready, click Next Step.

That’s it! Your MySQL database has been set up 
and the new user added to the database.

STEP 5 : Go To PHPMyAdmin and Sellect Your Database And Import [ SMM-PANEL-DB.sql ]. This File available on DATABASE Folder In OSPQUICKPANEL.zip File.

STEP 6 : Now Go To File Manager and open public_html then go Folder Name [ app ] Then Select ( config.php ) and click on Edit line no. 5,6 - Your-Domain.com To Your Domain Name.
and Replace Database Name,Password,User.

Now You Can Vist Your Admin Panel By Adding [ /admin ] on Your Domain name.
Example : ( https://your-domain-name.com/admin )

Setting Your all Details and Your SMM Panel Website is Ready To Go.

Thanks Agin For Your Order in OwnSMMPanel.in