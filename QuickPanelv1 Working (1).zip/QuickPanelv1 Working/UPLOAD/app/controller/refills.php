<?php

$title .= "Refills";

if( $_SESSION["msmbilisim_userlogin"] != 1  || $user["client_type"] == 1  ){
  Header("Location:".site_url('logout'));
}

$smmapi   = new SMMApi();
$fapi     = new socialsmedia_api();
$website_id = WEBSITE_ID;

$status_list  = ["all","pending","inprogress","completed","fail","processing","rejected","canceled"];
$search_statu = route(1); if( !route(1) ):  $route[1] = "all";  endif;

  if( !in_array($search_statu,$status_list) ):
    $route[1]         = "all";
  endif;

  if( route(2) ):
    $page         = route(2);
  else:
    $page         = 1;
  endif;
    if( route(1) != "all" ): $search  = "&& refill.refill_status='".route(1)."'"; else: $search = ""; endif;
    if( !empty(urldecode($_GET["search"])) ): $search.= " && ( orders.order_url LIKE '%".urldecode($_GET["search"])."%' || refill.refill_id LIKE '%".urldecode($_GET["search"])."%' || refill.refill_order_id LIKE '%".urldecode($_GET["search"])."%' ) "; endif;
    $c_id       = $user["client_id"];
    $to         = 25;
    $count      = $conn->query("SELECT * FROM refill INNER JOIN orders ON orders.order_id=refill.refill_order_id WHERE refill.refill_client_id='$c_id' $search ")->rowCount();
    $pageCount  = ceil($count/$to);
      if( $page > $pageCount ): $page = 1; endif;
    $where      = ($page*$to)-$to;
    $paginationArr = ["count"=>$pageCount,"current"=>$page,"next"=>$page+1,"previous"=>$page-1];

    $refills = $conn->prepare("SELECT * FROM refill INNER JOIN services INNER JOIN orders WHERE orders.order_id = refill.refill_order_id && services.service_id = orders.service_id && refill.refill_client_id=:c_id $search ORDER BY orders.order_id DESC LIMIT $where,$to ");
    $refills-> execute(array("c_id"=>$user["client_id"],"web_id"=>WEBSITE_ID ));
    $refills = $refills->fetchAll(PDO::FETCH_ASSOC);

  $refillsList = [];

    foreach ($refills as $refill) {
      $o["id"]    = $refill["refill_id"];
      $o["order_id"]    = $refill["order_id"];
      $o["start_count"]  = $refill["order_start"];
      $o["quantity"]  = $refill["order_quantity"];
      if( $refill["order_status"] == "completed" && substr($refill["order_remains"], 0,1) == "-" ):
        $o["remains"]  = "+".substr($refill["order_remains"], 1);
      else:
        $o["remains"]  = $refill["order_remains"];
      endif;
      $o["link"]    = $refill["order_url"];
      $o["service"]  = $refill["service_name"];
      $o["status"]  = $refill["refill_status"];
      $o["date"]  = date("Y-m-d H:i:s", (strtotime($refill["refill_create"])+$user["timezone"]));
      
      array_push($refillsList,$o);
    }

