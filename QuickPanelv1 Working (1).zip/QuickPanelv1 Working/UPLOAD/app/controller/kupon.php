<?php

$title .= "Kupon Kullan";

if( $_SESSION["msmbilisim_userlogin"] != 1  || $user["client_type"] == 1  ){
  Header("Location:".site_url('logout'));
}

if( !route(1) ){
	
	
	
	
	
	
	
	
	
  if( $_POST ){
    foreach ($_POST as $key => $value) {
      $_SESSION["data"][$key]  = $value;
    }
	
	
    $kuponadi  = $_POST["kuponadi"];
	
	
	
      if( empty($kuponadi) ){
        $error    = 1;
        $errorText= "Please fill in all fields.";
      }else{
		  
		  
		  
		$varmi = $conn->prepare("SELECT count(*) as toplam FROM kuponlar WHERE kuponadi = ?");
		$varmi->execute([$kuponadi]);
		$count = $varmi->fetch(PDO::FETCH_ASSOC);
		
		if($count["toplam"]>0){
			
			$kuponal = $conn->prepare("SELECT * FROM kuponlar WHERE kuponadi = ?");
			$kuponal->execute([$kuponadi]);
			$kuponal = $kuponal->fetch(PDO::FETCH_ASSOC);
			
			
			if($kuponal["adet"]>0){
				
				//kullanmismi
			$kullanmismi = $conn->prepare("SELECT * FROM kupon_kullananlar WHERE uye_id=:uye_id and kuponadi =:kuponadi");
			$kullanmismi->execute(array("uye_id"=>$user["client_id"], "kuponadi"=>$kuponal["kuponadi"]));
			$kullanmismi = $kullanmismi->fetch(PDO::FETCH_ASSOC);
			
			if($kullanmismi>0){
				
				 $error    = 1;
				$errorText= "You have already used this coupon.";
		  
			}else{
				
				
				$uyebakiye = $conn->prepare("SELECT * FROM clients WHERE client_id=:client_id");
				$uyebakiye->execute(array("client_id"=>$user["client_id"]));
				$uyebakiye = $uyebakiye->fetch(PDO::FETCH_ASSOC);
				$uyebakiyesi = $uyebakiye["balance"];
				


				
				
				$yenibakiye = $kuponal["tutar"]+$uyebakiyesi;
				
				
				$conn->beginTransaction();
				$bakiyeguncelle = $conn->prepare("UPDATE clients SET balance=:balances  WHERE client_id=:c_id ");
				$bakiyeguncelle-> execute(array("c_id"=>$user["client_id"], "balances"=>$yenibakiye ));
				
				$adetdusur = $conn->prepare("UPDATE kuponlar SET adet=adet-1 WHERE id=:kupon_id ");
				$adetdusur-> execute(array("kupon_id"=>$kuponal["id"] ));
				
				$kullanildi = $conn->prepare("insert into kupon_kullananlar SET uye_id=:uye_id,kuponadi=:kuponadi,tutar=:tutar ");
				$kullanildi-> execute(array("uye_id"=>$user["client_id"], "kuponadi"=>$kuponal["kuponadi"],"tutar"=>$kuponal["tutar"] ));
				$conn->commit();
				
				
				$success    = 1;
				$successText= "The coupon has been added to your balance. Thanks.";
				
				
			}
			//kullanmismi
				
			}else{
				 $error    = 1;
				$errorText= "This coupon has expired.";
			}
			
			
			
		}else{
		  $error    = 1;
          $errorText= "No coupon found.";
		}
		
		
		
      }
  }
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	



}elseif( route(1) && preg_replace('/[^a-zA-Z]/', '', route(1))  ){

  header('Location:'.site_url('404'));

}
