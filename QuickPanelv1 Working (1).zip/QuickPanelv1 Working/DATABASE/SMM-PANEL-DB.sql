-- phpMyAdmin SQL Dump
-- version 4.9.7
-- https://www.phpmyadmin.net/
--
-- Host: localhost:3306
-- Generation Time: Nov 22, 2021 at 04:13 PM
-- Server version: 10.3.32-MariaDB
-- PHP Version: 7.3.32

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `ospdev_smm`
--

-- --------------------------------------------------------

--
-- Table structure for table `bank_accounts`
--

CREATE TABLE `bank_accounts` (
  `id` int(11) NOT NULL,
  `bank_name` varchar(225) NOT NULL,
  `bank_sube` varchar(225) NOT NULL,
  `bank_hesap` varchar(225) NOT NULL,
  `bank_iban` text NOT NULL,
  `bank_alici` varchar(225) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `categories`
--

CREATE TABLE `categories` (
  `category_id` int(11) NOT NULL,
  `category_name` text COLLATE utf8mb4_bin NOT NULL,
  `category_line` double NOT NULL,
  `category_type` enum('1','2') CHARACTER SET utf8 NOT NULL DEFAULT '2',
  `category_secret` enum('1','2') COLLATE utf8mb4_bin NOT NULL DEFAULT '2',
  `category_icon` text COLLATE utf8mb4_bin NOT NULL,
  `is_refill` enum('true','false') COLLATE utf8mb4_bin NOT NULL DEFAULT 'false'
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_bin;

--
-- Dumping data for table `categories`
--

INSERT INTO `categories` (`category_id`, `category_name`, `category_line`, `category_type`, `category_secret`, `category_icon`, `is_refill`) VALUES
(1, '♛  SocialKart ( PROMO ) 🔥⭐', 1, '2', '2', '', 'false'),
(2, ' ♛ Instagram Followers [♻️ Guaranteed 0-30 Days]', 2, '2', '2', '', 'false'),
(3, ' ♛ Instagram Followers [♻️ Guaranteed 31-90 Days]', 3, '2', '2', '', 'false'),
(4, ' ♛ Instagram Followers [♻️ Guaranteed 91-365 Days]', 4, '2', '2', '', 'false'),
(5, ' ♛ Instagram Followers [🔥 TARGETED ]', 5, '2', '2', '', 'false');

-- --------------------------------------------------------

--
-- Table structure for table `childpanels`
--

CREATE TABLE `childpanels` (
  `id` int(11) NOT NULL,
  `client_id` int(11) NOT NULL,
  `domain` varchar(191) COLLATE utf8_unicode_ci NOT NULL,
  `currency` varchar(191) COLLATE utf8_unicode_ci NOT NULL,
  `child_username` varchar(191) COLLATE utf8_unicode_ci NOT NULL,
  `child_password` varchar(191) COLLATE utf8_unicode_ci NOT NULL,
  `charge` double NOT NULL,
  `status` enum('active','terminated','disabled') COLLATE utf8_unicode_ci NOT NULL,
  `renewal_date` date NOT NULL,
  `date_created` datetime NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `clients`
--

CREATE TABLE `clients` (
  `client_id` int(11) NOT NULL,
  `name` varchar(255) CHARACTER SET utf8 NOT NULL,
  `email` varchar(225) CHARACTER SET utf8 NOT NULL,
  `username` varchar(225) CHARACTER SET utf8 NOT NULL,
  `password` text CHARACTER SET utf8 NOT NULL,
  `telephone` varchar(225) CHARACTER SET utf8 NOT NULL,
  `balance` double NOT NULL DEFAULT 0,
  `balance_type` enum('1','2') CHARACTER SET utf8 NOT NULL DEFAULT '2',
  `debit_limit` double DEFAULT NULL,
  `spent` double NOT NULL DEFAULT 0,
  `register_date` datetime NOT NULL,
  `login_date` datetime DEFAULT NULL,
  `login_ip` varchar(225) CHARACTER SET utf8 DEFAULT NULL,
  `apikey` text CHARACTER SET utf8 DEFAULT NULL,
  `tel_type` enum('1','2') CHARACTER SET utf8 NOT NULL DEFAULT '1' COMMENT '2 -> ON, 1 -> OFF	',
  `email_type` enum('1','2') CHARACTER SET utf8 NOT NULL DEFAULT '1' COMMENT '2 -> ON, 1 -> OFF	',
  `client_type` enum('1','2') CHARACTER SET utf8 NOT NULL DEFAULT '2' COMMENT '2 -> ON, 1 -> OFF',
  `access` text CHARACTER SET utf8 NOT NULL,
  `lang` varchar(255) CHARACTER SET utf8 NOT NULL DEFAULT 'en',
  `timezone` double NOT NULL DEFAULT 0
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `clients`
--

INSERT INTO `clients` (`client_id`, `name`, `email`, `username`, `password`, `telephone`, `balance`, `balance_type`, `debit_limit`, `spent`, `register_date`, `login_date`, `login_ip`, `apikey`, `tel_type`, `email_type`, `client_type`, `access`, `lang`, `timezone`) VALUES
(1, 'Admin Account', 'admin@ownsmmpanel.in', 'adminac', '69005bb62e9622ee1de61958aacf0f63', '08355965199', 0, '2', NULL, 0, '2021-11-21 18:32:15', '2021-11-22 18:57:01', '103.195.74.137', '100266e5887fe1da4411fc648664d6b7', '1', '1', '2', '{\"admin_access\":\"1\",\"users\":\"1\",\"orders\":\"1\",\"subscriptions\":\"1\",\"dripfeed\":\"1\",\"services\":\"1\",\"payments\":\"1\",\"tickets\":\"1\",\"reports\":\"1\",\"general_settings\":\"1\",\"pages\":\"1\",\"payments_settings\":\"1\",\"bank_accounts\":\"1\",\"payments_bonus\":\"1\",\"alert_settings\":\"1\",\"providers\":\"1\",\"themes\":\"1\",\"admins\":\"1\",\"language\":\"1\",\"meta\":\"1\",\"proxy\":\"1\",\"kuponlar\":\"1\",\"child-panels\":\"1\"}', 'en', 0);

-- --------------------------------------------------------

--
-- Table structure for table `clients_category`
--

CREATE TABLE `clients_category` (
  `id` int(11) NOT NULL,
  `client_id` int(11) NOT NULL,
  `category_id` int(11) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `clients_price`
--

CREATE TABLE `clients_price` (
  `id` int(11) NOT NULL,
  `client_id` int(11) NOT NULL,
  `service_id` int(11) NOT NULL,
  `service_price` double NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `clients_service`
--

CREATE TABLE `clients_service` (
  `id` int(11) NOT NULL,
  `client_id` int(11) NOT NULL,
  `service_id` int(11) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `client_report`
--

CREATE TABLE `client_report` (
  `id` int(11) NOT NULL,
  `client_id` int(11) NOT NULL,
  `action` text NOT NULL,
  `report_ip` varchar(225) NOT NULL,
  `report_date` datetime NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `kuponlar`
--

CREATE TABLE `kuponlar` (
  `id` int(11) NOT NULL,
  `kuponadi` varchar(255) NOT NULL,
  `adet` int(11) NOT NULL,
  `tutar` double NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `kupon_kullananlar`
--

CREATE TABLE `kupon_kullananlar` (
  `id` int(11) NOT NULL,
  `uye_id` int(11) NOT NULL,
  `kuponadi` varchar(255) NOT NULL,
  `tutar` double NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `languages`
--

CREATE TABLE `languages` (
  `id` int(11) NOT NULL,
  `language_name` varchar(225) NOT NULL,
  `language_code` varchar(225) NOT NULL,
  `language_type` enum('2','1') NOT NULL DEFAULT '2',
  `default_language` enum('0','1') NOT NULL DEFAULT '0'
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

--
-- Dumping data for table `languages`
--

INSERT INTO `languages` (`id`, `language_name`, `language_code`, `language_type`, `default_language`) VALUES
(1, 'English', 'en', '2', '1');

-- --------------------------------------------------------

--
-- Table structure for table `orders`
--

CREATE TABLE `orders` (
  `order_id` int(11) NOT NULL,
  `client_id` int(11) NOT NULL,
  `service_id` int(11) NOT NULL,
  `api_orderid` int(11) NOT NULL DEFAULT 0,
  `order_error` text NOT NULL,
  `order_detail` text DEFAULT NULL,
  `order_api` int(11) NOT NULL DEFAULT 0,
  `api_serviceid` int(11) NOT NULL DEFAULT 0,
  `api_charge` double NOT NULL DEFAULT 0,
  `api_currencycharge` double DEFAULT 1,
  `order_profit` double NOT NULL,
  `order_quantity` double NOT NULL,
  `order_extras` text NOT NULL,
  `order_charge` double NOT NULL,
  `dripfeed` enum('1','2','3') DEFAULT '1' COMMENT '2 -> ON, 1 -> OFF',
  `dripfeed_id` double NOT NULL DEFAULT 0,
  `subscriptions_id` double NOT NULL DEFAULT 0,
  `subscriptions_type` enum('1','2') NOT NULL DEFAULT '1' COMMENT '2 -> ON, 1 -> OFF',
  `dripfeed_totalcharges` double DEFAULT NULL,
  `dripfeed_runs` double DEFAULT NULL,
  `dripfeed_delivery` double NOT NULL DEFAULT 0,
  `dripfeed_interval` double DEFAULT NULL,
  `dripfeed_totalquantity` double DEFAULT NULL,
  `dripfeed_status` enum('active','completed','canceled') NOT NULL DEFAULT 'active',
  `order_url` text NOT NULL,
  `order_start` double NOT NULL DEFAULT 0,
  `order_finish` double NOT NULL DEFAULT 0,
  `order_remains` double NOT NULL DEFAULT 0,
  `order_create` datetime NOT NULL,
  `order_status` enum('pending','inprogress','completed','partial','processing','canceled') NOT NULL DEFAULT 'pending',
  `subscriptions_status` enum('active','paused','completed','canceled','expired','limit') NOT NULL DEFAULT 'active',
  `subscriptions_username` text DEFAULT NULL,
  `subscriptions_posts` double DEFAULT NULL,
  `subscriptions_delivery` double NOT NULL DEFAULT 0,
  `subscriptions_delay` double DEFAULT NULL,
  `subscriptions_min` double DEFAULT NULL,
  `subscriptions_max` double DEFAULT NULL,
  `subscriptions_expiry` date DEFAULT NULL,
  `is_refill` enum('true','false') NOT NULL DEFAULT 'false',
  `last_check` datetime NOT NULL,
  `order_where` enum('site','api') NOT NULL DEFAULT 'site'
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `pages`
--

CREATE TABLE `pages` (
  `page_id` int(11) NOT NULL,
  `page_name` varchar(225) NOT NULL,
  `page_get` varchar(225) NOT NULL,
  `page_content` text NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

--
-- Dumping data for table `pages`
--

INSERT INTO `pages` (`page_id`, `page_name`, `page_get`, `page_content`) VALUES
(1, 'Login', 'auth', ''),
(2, 'New Order', 'neworder', ''),
(3, 'Services', 'services', ''),
(4, 'Add Funds', 'addfunds', ''),
(5, 'Tickets', 'tickets', ''),
(6, 'Terms', 'terms', '<h2>General</h2><p><br></p><p>By placing an order with OSP QuickPanel, you automatically accept all the below-listed terms of service whether you read them or not.</p><p>We reserve the right to change these terms of service without notice. You are expected to read all terms of service before placing an order to ensure you are up to date with any changes or any future changes.</p><p>You will only use the OSP QuickPanel website in a manner that follows all agreements made with Instagram/Facebook/Twitter/Youtube/Other social media site on their individual Terms of Service page.&nbsp; OSP QuickPanel rates are subject to change at any time without notice. The payment/refund policy stays in effect in the case of rate changes. OSP QuickPanel does not guarantee a delivery time for any services. We offer our best estimation for when the order will be delivered. This is only an estimation and OSP QuickPanel will not refund orders that are processing if you feel they are taking too long. OSP QuickPanel tries hard to deliver exactly what is expected from us by our re-sellers. In this case, we reserve the right to change a service type if we deem it necessary to complete an order.</p><p><br></p><h2>Disclaimer:</h2><p><br></p><p>OSP QuickPanel will not be responsible for any damages you or your business may suffer.</p><p><span style=\"color: inherit; font-family: inherit; font-size: 18px;\">Liabilities:</span></p><p><span style=\"color: inherit; font-family: inherit; font-size: 18px;\"><br></span></p><p>OSP QuickPanel is in no way liable for any account suspension or picture deletion done by Instagram or Twitter or Facebook or YouTube or Other Social Media.</p><p><br></p><h2>SERVICES&nbsp;</h2><p><br></p><p>OSP QuickPanel will only be used to promote your Instagram/Twitter/Facebook or Social account and help boost your \"Appearance\" only.</p><p>We DO NOT guarantee your new followers will interact with you, we simply guarantee you to get the followers you pay for.</p><p>We DO NOT guarantee 100% of our accounts will have a profile picture, full bio, and uploaded pictures, although we strive to make this the reality for all accounts.</p><p>You will not upload anything into the OSP QuickPanel site including nudity or any material that is not accepted or suitable for the Instagram/Twitter/Facebook or Social Media community.</p><p>Private accounts would not get a refund! Please ensure that your account is public before ordering. will only be used to promote your Instagram/Twitter/Facebook or Social account and help boost your \"Appearance\" only.</p><p>We DO NOT guarantee your new followers will interact with you, we simply guarantee you to get the followers you pay for.</p><p>We DO NOT guarantee 100% of our accounts will have a profile picture, full bio, and uploaded pictures, although we strive to make this the reality for all accounts.</p><p>You will not upload anything into the OSP QuickPanel site including nudity or any material that is not accepted or suitable for the Instagram/Twitter/Facebook or Social Media community.</p><p>Private accounts would not get a refund! Please ensure that your account is public before ordering. will only be used to promote your Instagram/Twitter/Facebook or Social account and help boost your \"Appearance\" only.</p><p>We DO NOT guarantee your new followers will interact with you, we simply guarantee you to get the followers you pay for.</p><p>We DO NOT guarantee 100% of our accounts will have a profile picture, full bio, and uploaded pictures, although we strive to make this the reality for all accounts.</p><p>You will not upload anything into the OSP QuickPanel site including nudity or any material that is not accepted or suitable for the Instagram/Twitter/Facebook or Social Media community.</p><p>Private accounts would not get a refund! Please ensure that your account is public before ordering.</p><p><br></p><h2>Refund Policy</h2><p><br></p><p>No refunds will be made to your payment method. After a deposit has been completed, there is no way to reverse it. You must use your balance on orders from OSP QuickPanel.</p><p>You agree that once you complete a payment, you will not file a dispute or a chargeback against us for any reason.</p><p>If you file a dispute or chargeback against us after a deposit, we reserve the right to terminate all future orders, ban you from our site. We also reserve the right to take away any followers or likes we delivered to your or your client\'s Instagram/Facebook/Twitter or other social media account.</p><p>Orders placed in Just Another Panel will not be refunded or canceled after they are placed. You will receive a refund credit to your OSP QuickPanel account if the order is non-deliverable</p><p>Misplaced or Private account orders will not qualify for a refund. Be sure to confirm every order before placing it.</p><p>Fraudulent activity such as using unauthorized or stolen credit cards will lead to the termination of your account. There are no exceptions.</p><p>Please do not use more than one server at the same time for the same page. We cannot give you the correct followers/likes number in that case. We will not refund these orders.</p><p><br></p><h2>Privacy Policy</h2><p><br></p><p>This policy covers how we use your personal information. We take your privacy seriously and will take all measures to protect your personal information.</p><p>Any personal information received will only be used to fill your order. We will not sell or redistribute your personal information to anyone. All personal information is encrypted and saved in secure servers.</p>'),
(7, 'FAQ', 'faq', ''),
(10, 'Child Panel', 'child-panels', '');

-- --------------------------------------------------------

--
-- Table structure for table `payments`
--

CREATE TABLE `payments` (
  `payment_id` int(11) NOT NULL,
  `client_id` int(11) NOT NULL DEFAULT 0,
  `client_balance` double NOT NULL DEFAULT 0,
  `payment_amount` double NOT NULL DEFAULT 0,
  `payment_privatecode` double DEFAULT NULL,
  `payment_method` int(11) NOT NULL DEFAULT -1,
  `payment_status` enum('1','2','3') NOT NULL DEFAULT '1',
  `payment_delivery` enum('1','2') NOT NULL DEFAULT '1',
  `payment_note` text DEFAULT NULL,
  `payment_mode` enum('Manuel','Otomatik') NOT NULL DEFAULT 'Otomatik',
  `payment_create_date` datetime NOT NULL DEFAULT current_timestamp(),
  `payment_update_date` datetime NOT NULL DEFAULT current_timestamp(),
  `payment_ip` varchar(225) DEFAULT NULL,
  `payment_extra` text DEFAULT NULL,
  `payment_bank` int(11) NOT NULL DEFAULT 0
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

--
-- Dumping data for table `payments`
--

INSERT INTO `payments` (`payment_id`, `client_id`, `client_balance`, `payment_amount`, `payment_privatecode`, `payment_method`, `payment_status`, `payment_delivery`, `payment_note`, `payment_mode`, `payment_create_date`, `payment_update_date`, `payment_ip`, `payment_extra`, `payment_bank`) VALUES
(1, 1, 0, 100, NULL, 15, '1', '1', NULL, 'Otomatik', '2021-11-21 19:25:49', '2021-11-21 14:55:49', '77.111.245.14', '1637502949', 0),
(2, 1, 0, 63638, NULL, 13, '1', '1', NULL, 'Otomatik', '2021-11-21 19:33:28', '2021-11-21 15:03:28', '103.195.74.137', 'af43b604e63c0ee0c7770952a933efe0', 0),
(3, 1, 0, 100, NULL, 12, '1', '1', NULL, 'Otomatik', '2021-11-21 19:34:43', '2021-11-21 15:04:43', '103.195.74.137', 'ORDS8967822', 0),
(4, 1, 0, 10, NULL, 12, '1', '1', NULL, 'Otomatik', '2021-11-22 19:31:59', '2021-11-22 15:01:59', '103.195.74.137', 'ORDS11677062', 0);

-- --------------------------------------------------------

--
-- Table structure for table `payments_bonus`
--

CREATE TABLE `payments_bonus` (
  `bonus_id` int(11) NOT NULL,
  `bonus_method` int(11) NOT NULL,
  `bonus_from` double NOT NULL,
  `bonus_amount` double NOT NULL,
  `bonus_type` enum('1','2') NOT NULL DEFAULT '2'
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `payment_methods`
--

CREATE TABLE `payment_methods` (
  `id` int(11) NOT NULL,
  `method_name` varchar(225) NOT NULL,
  `method_get` varchar(225) NOT NULL,
  `method_min` double NOT NULL,
  `method_max` double NOT NULL,
  `method_type` enum('1','2') NOT NULL DEFAULT '2' COMMENT '2 -> ON, 1 -> OFF	',
  `method_extras` text NOT NULL,
  `method_line` double NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `payment_methods`
--

INSERT INTO `payment_methods` (`id`, `method_name`, `method_get`, `method_min`, `method_max`, `method_type`, `method_extras`, `method_line`) VALUES
(12, 'PayTM', 'paytm', 1, 10000, '2', '{\"method_type\":\"2\",\"name\":\"PayTM\",\"min\":\"1\",\"max\":\"10000\",\"merchant_key\":\"\",\"merchant_mid\":\"\",\"merchant_website\":\"DEFAULT\",\"fee\":\"0\"}', 2),
(13, 'RazorPay', 'razorpay', 1, 0, '2', '{\"method_type\":\"2\",\"name\":\"Razorpay\",\"min\":\"1\",\"max\":\"0\",\"public_key\":\"\",\"key_secret\":\"\",\"merchant_website\":\"https:\\/\\/api.razorpay.com\\/v1\\/orders\",\"fee\":\"0\"}', 1),
(14, 'PayTM QR', 'paytmqr', 10, 10000, '2', '{\"method_type\":\"2\",\"name\":\"PayTM QR\",\"min\":\"10\",\"max\":\"10000\",\"merchant_key\":\"https:\\/\\/i.imgur.com\\/vqgcKBY.png\",\"merchant_mid\":\"\",\"merchant_website\":\"DEFAULT\",\"fee\":\"3\"}', 10),
(15, 'Perfect Money', 'perfectmoney', 1, 10000, '2', '{\"method_type\":\"2\",\"name\":\"Perfect Money USD \",\"min\":\"1\",\"max\":\"10000\",\"passphrase\":\"\",\"usd\":\"\",\"merchant_website\":\"\",\"fee\":\"0\"}', 10);

-- --------------------------------------------------------

--
-- Table structure for table `serviceapi_alert`
--

CREATE TABLE `serviceapi_alert` (
  `id` int(11) NOT NULL,
  `service_id` int(11) NOT NULL,
  `serviceapi_alert` text NOT NULL,
  `servicealert_extra` text NOT NULL,
  `servicealert_date` datetime NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `services`
--

CREATE TABLE `services` (
  `service_id` int(11) NOT NULL,
  `service_api` int(11) NOT NULL DEFAULT 0,
  `api_service` int(11) NOT NULL DEFAULT 0,
  `api_servicetype` enum('1','2') NOT NULL DEFAULT '2',
  `api_detail` text NOT NULL,
  `category_id` int(11) NOT NULL,
  `service_line` double NOT NULL,
  `service_type` enum('1','2') NOT NULL DEFAULT '2',
  `service_package` enum('1','2','3','4','5','6','7','8','9','10','11','12','13','14','15','16','17') NOT NULL,
  `service_name` text CHARACTER SET utf8mb4 COLLATE utf8mb4_bin NOT NULL,
  `service_description` text DEFAULT NULL,
  `service_price` double NOT NULL DEFAULT 0,
  `service_min` double NOT NULL,
  `service_max` double NOT NULL,
  `service_dripfeed` enum('1','2') NOT NULL DEFAULT '1',
  `service_autotime` double NOT NULL DEFAULT 0,
  `service_autopost` double NOT NULL DEFAULT 0,
  `service_speed` enum('1','2','3','4') NOT NULL,
  `want_username` enum('1','2') NOT NULL DEFAULT '1',
  `service_secret` enum('1','2') NOT NULL DEFAULT '2',
  `price_type` enum('normal','percent','amount') NOT NULL DEFAULT 'normal',
  `price_cal` text DEFAULT NULL,
  `instagram_second` enum('1','2') NOT NULL DEFAULT '2',
  `start_count` enum('none','instagram_follower','instagram_photo','') NOT NULL,
  `instagram_private` enum('1','2') NOT NULL,
  `name_lang` text DEFAULT NULL,
  `description_lang` text DEFAULT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

--
-- Dumping data for table `services`
--

INSERT INTO `services` (`service_id`, `service_api`, `api_service`, `api_servicetype`, `api_detail`, `category_id`, `service_line`, `service_type`, `service_package`, `service_name`, `service_description`, `service_price`, `service_min`, `service_max`, `service_dripfeed`, `service_autotime`, `service_autopost`, `service_speed`, `want_username`, `service_secret`, `price_type`, `price_cal`, `instagram_second`, `start_count`, `instagram_private`, `name_lang`, `description_lang`) VALUES
(1, 1, 1, '2', '{\"min\":\"10\",\"max\":\"30000\",\"rate\":\"5\",\"currency\":\"INR\"}', 1, 1, '2', '1', 'Instagram Likes | HQ | Fast | No Drop | MAX 30K ⛔⚡️⚡️🔥🔥🔥', '?Quality: High Quality\r\n⌛ Start: Instant\r\n⚡Speed: Up to 30K/Day\r\n♻️Refill: No Refill / No Drop\r\n⬇️Minimum: 10\r\n⬆️Maximum: 30,000', 5.5, 10, 30000, '1', 0, 0, '1', '1', '2', 'normal', NULL, '2', 'none', '1', NULL, NULL),
(2, 1, 5, '2', '{\"min\":\"50\",\"max\":\"100000\",\"rate\":\"3\",\"currency\":\"INR\"}', 1, 1, '2', '1', 'Instagram Likes | Cheapest | Fast | MAX 100K ⛔ 🔥🔥⚡️⚡️', '?Quality: High Quality\r\n⌛ Start: Instant\r\n⚡Speed: Very Fast speed\r\n♻️Refill: No Refill\r\n⬇️Minimum: 10\r\n⬆️Maximum: 100,000', 3.3, 50, 100000, '1', 0, 0, '1', '1', '2', 'normal', NULL, '2', 'none', '1', NULL, NULL),
(3, 1, 3, '2', '{\"min\":\"50\",\"max\":\"20000\",\"rate\":\"25\",\"currency\":\"INR\"}', 1, 1, '2', '1', 'Instagram Followers | Mix | Speed: Up To 5K/Hour | MAX 20K  ⛔ 🔥🔥🔥⚡️⚡️', '?Quality: High Quality / Mix\r\n⌛ Start: 0-1h\r\n⚡Speed: Up To 5K/Hour\r\n♻️Refill: No Refill\r\n⬇️Minimum: 50\r\n⬆️Maximum: 20,000', 27.5, 50, 20000, '1', 0, 0, '1', '1', '2', 'normal', NULL, '2', 'none', '1', NULL, NULL),
(4, 1, 2, '2', '{\"min\":\"25\",\"max\":\"15000\",\"rate\":\"15\",\"currency\":\"INR\"}', 1, 1, '2', '1', 'Instagram Followers | Cheapest | Fastest | MAX 15K  ⛔ 🔥🔥⚡️⚡️', '?Quality: Low Quality\r\n⌛ Start: 0-1h\r\n⚡Speed: Fast\r\n♻️Refill: No Refill / No refunds / High Drops are possible\r\n⬇️Minimum: 25\r\n⬆️Maximum: 15,000', 16.5, 25, 15000, '1', 0, 0, '1', '1', '2', 'normal', NULL, '2', 'none', '1', NULL, NULL),
(5, 1, 8, '2', '{\"min\":\"100\",\"max\":\"50000000\",\"rate\":\"0.9\",\"currency\":\"INR\"}', 1, 1, '2', '1', 'Instagram Views | New | Fast | MAX 4M ⭐', '?Quality: High Quality\r\n⌛ Start: 0-1h\r\n⚡Speed: Fast\r\n♻️Refill: No Refill\r\n⬇️Minimum: 10\r\n⬆️Maximum: 5,000,000', 0.99, 100, 50000000, '1', 0, 0, '1', '1', '2', 'normal', NULL, '2', 'none', '1', NULL, NULL),
(6, 1, 7, '2', '{\"min\":\"100\",\"max\":\"5000000\",\"rate\":\"0.9\",\"currency\":\"INR\"}', 1, 1, '2', '1', 'Instagram Views | Cheapest | MAX 5M', '?Quality: Real\r\n⌛ Start: Instant\r\n⚡Speed: Fast speed\r\n⬇️Minimum: 100\r\n⬆️Maximum: 10,000,000', 0.99, 100, 5000000, '1', 0, 0, '1', '1', '2', 'normal', NULL, '2', 'none', '1', NULL, NULL),
(7, 1, 21, '2', '{\"min\":\"10\",\"max\":\"15000\",\"rate\":\"49\",\"currency\":\"INR\"}', 2, 1, '2', '1', 'Instagram Followers | Stable | Mixed Quality | AR30 | MAX 15K  ⛔', '?Quality: Mixed Quality\r\n⌛ Start: 0-5h\r\n⚡Speed: Fastest\r\n♻️Refill: 30Days Auto-Refill\r\n⬇️Minimum: 50\r\n⬆️Maximum: 50,000', 53.9, 10, 15000, '1', 0, 0, '1', '1', '2', 'normal', NULL, '2', 'none', '1', NULL, NULL),
(8, 1, 23, '2', '{\"min\":\"100\",\"max\":\"5000\",\"rate\":\"47\",\"currency\":\"INR\"}', 2, 1, '2', '1', 'Instagram Followers | R30 | MAX 5K  ♻️', '?Quality: High Quality\r\n⌛ Start: 0-3h\r\n⚡Speed: Up To 2K/Day\r\n?Link: Username\r\n♻️Refill: 30Days\r\n⬇️Minimum: 100\r\n⬆️Maximum: 5,000', 51.7, 100, 5000, '1', 0, 0, '1', '1', '2', 'normal', NULL, '2', 'none', '1', NULL, NULL),
(9, 1, 29, '2', '{\"min\":\"5\",\"max\":\"100000\",\"rate\":\"58\",\"currency\":\"INR\"}', 3, 1, '2', '1', 'Instagram Followers | Good | R60  ♻️', '?Quality: Real\r\n⌛ Start: 0-1h\r\n⚡Speed: Up To 10K/Day\r\n♻️Refill: 60Days\r\n⬇️Minimum: 5\r\n⬆️Maximum: 100,000', 63.8, 5, 100000, '1', 0, 0, '1', '1', '2', 'normal', NULL, '2', 'none', '1', NULL, NULL),
(10, 1, 30, '2', '{\"min\":\"5\",\"max\":\"100000\",\"rate\":\"65\",\"currency\":\"INR\"}', 3, 1, '2', '1', 'Instagram Followers | Good | R90  ♻️', '?Quality: High Quality\r\n⌛ Start: 0-1h\r\n⚡Speed: Up To 10K/Day\r\n♻️Refill: 90Days\r\n⬇️Minimum: 5\r\n⬆️Maximum: 100,000', 71.5, 5, 100000, '1', 0, 0, '1', '1', '2', 'normal', NULL, '2', 'none', '1', NULL, NULL),
(11, 1, 31, '2', '{\"min\":\"10\",\"max\":\"1000000\",\"rate\":\"58\",\"currency\":\"INR\"}', 4, 1, '2', '1', 'Instagram Followers | HQ | Fast | R99 | Max 1M  ♻️ ⭐⭐🔥⚡️', '?Quality: Hight Quality\r\n⌛ Start: Instant\r\n⚡Speed: Very Fast / Up to 20K/Day\r\n♻️Refill: 99Days\r\n⬇️Minimum: 10\r\n⬆️Maximum: 1,000,000', 63.8, 10, 1000000, '1', 0, 0, '1', '1', '2', 'normal', NULL, '2', 'none', '1', NULL, NULL),
(12, 1, 32, '2', '{\"min\":\"10\",\"max\":\"100000\",\"rate\":\"55\",\"currency\":\"INR\"}', 4, 1, '2', '1', 'Instagram Followers | Real| Fast | R99 Days | Max 100K  ♻️ ⭐⭐🔥⚡️', '?Quality: Real\r\n⌛ Start: 0-1h\r\n⚡Speed: Fast\r\n♻️Refill: 99Days\r\n⬇️Minimum: 10\r\n⬆️Maximum: 100,000', 60.5, 10, 100000, '1', 0, 0, '1', '1', '2', 'normal', NULL, '2', 'none', '1', NULL, NULL),
(13, 1, 36, '2', '{\"min\":\"50\",\"max\":\"5000\",\"rate\":\"117\",\"currency\":\"INR\"}', 5, 1, '2', '1', 'Instagram Followers | Indian | No Refill | MAX 5K', '?Quality: Real\r\n⌛ Start: Instant-1h\r\n⚡Speed: Up To 15K/Day\r\n♻️Refill: No Refill\r\n⬇️Minimum: 50\r\n⬆️Maximum: 5,000', 128.7, 50, 5000, '1', 0, 0, '1', '1', '2', 'normal', NULL, '2', 'none', '1', NULL, NULL),
(14, 1, 37, '2', '{\"min\":\"500\",\"max\":\"47500\",\"rate\":\"119\",\"currency\":\"INR\"}', 5, 1, '2', '1', 'Instagram Followers | India | Real | R30 | MAX 45K', '?Quality: Real\r\n⌛ Start: Instant-1h\r\n⚡Speed: Up To 10-20K/Day\r\n?Link: https://instagram.com/username\r\n♻️Refill: 30days\r\n⬇️Minimum: 500\r\n⬆️Maximum: 47,500', 130.9, 500, 47500, '1', 0, 0, '1', '1', '2', 'normal', NULL, '2', 'none', '1', NULL, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `service_api`
--

CREATE TABLE `service_api` (
  `id` int(11) NOT NULL,
  `api_name` varchar(225) NOT NULL,
  `api_url` text NOT NULL,
  `api_key` varchar(225) NOT NULL,
  `api_type` int(11) NOT NULL,
  `api_limit` double NOT NULL DEFAULT 0,
  `currency` enum('INR','USD') DEFAULT NULL,
  `api_alert` enum('1','2') NOT NULL DEFAULT '2' COMMENT '2 -> Gönder, 1 -> Gönderildi'
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

--
-- Dumping data for table `service_api`
--

INSERT INTO `service_api` (`id`, `api_name`, `api_url`, `api_key`, `api_type`, `api_limit`, `currency`, `api_alert`) VALUES
(1, 'SocialKart.in', 'https://socialkart.in/api/v2', 'be8de88407aacee583531ddf9d65d4ff', 1, 0, 'INR', '2');

-- --------------------------------------------------------

--
-- Table structure for table `settings`
--

CREATE TABLE `settings` (
  `id` int(11) NOT NULL,
  `site_seo` text NOT NULL,
  `site_title` text DEFAULT NULL,
  `site_description` text DEFAULT NULL,
  `site_keywords` text DEFAULT NULL,
  `site_logo` text DEFAULT NULL,
  `site_name` text DEFAULT NULL,
  `site_currency` varchar(2555) NOT NULL DEFAULT 'try',
  `favicon` text DEFAULT NULL,
  `site_language` varchar(225) NOT NULL DEFAULT 'tr',
  `site_theme` text NOT NULL,
  `site_theme_alt` text DEFAULT NULL,
  `recaptcha` enum('1','2') NOT NULL DEFAULT '1',
  `recaptcha_key` text DEFAULT NULL,
  `recaptcha_secret` text DEFAULT NULL,
  `custom_header` text DEFAULT NULL,
  `custom_footer` text DEFAULT NULL,
  `ticket_system` enum('1','2') NOT NULL DEFAULT '2',
  `register_page` enum('1','2') NOT NULL DEFAULT '2',
  `service_speed` enum('1','2') NOT NULL,
  `service_list` enum('1','2') NOT NULL,
  `dolar_charge` double NOT NULL,
  `euro_charge` double NOT NULL,
  `smtp_user` text NOT NULL,
  `smtp_pass` text NOT NULL,
  `smtp_server` text NOT NULL,
  `smtp_port` varchar(225) NOT NULL,
  `smtp_protocol` enum('0','ssl','tls') NOT NULL,
  `alert_type` enum('1','2','3') NOT NULL,
  `alert_newbankpayment` enum('1','2') NOT NULL,
  `alert_newmanuelservice` enum('1','2') NOT NULL,
  `alert_newticket` enum('1','2') NOT NULL,
  `alert_apibalance` enum('1','2') NOT NULL,
  `alert_serviceapialert` enum('1','2') NOT NULL,
  `sms_provider` varchar(225) NOT NULL,
  `sms_title` varchar(225) NOT NULL,
  `sms_user` varchar(225) NOT NULL,
  `sms_pass` varchar(225) NOT NULL,
  `sms_validate` enum('0','1') NOT NULL DEFAULT '0' COMMENT '1 -> OK, 0 -> NO',
  `admin_mail` varchar(225) NOT NULL,
  `admin_telephone` varchar(225) NOT NULL,
  `resetpass_page` enum('1','2') NOT NULL,
  `resetpass_sms` enum('1','2') NOT NULL,
  `resetpass_email` enum('1','2') NOT NULL,
  `site_maintenance` enum('1','2') NOT NULL DEFAULT '2',
  `servis_siralama` varchar(255) NOT NULL,
  `bronz_statu` int(11) NOT NULL,
  `silver_statu` int(11) NOT NULL,
  `gold_statu` int(11) NOT NULL,
  `bayi_statu` int(11) NOT NULL,
  `ns1` varchar(191) DEFAULT NULL,
  `ns2` varchar(191) DEFAULT NULL,
  `childpanel_price` double DEFAULT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

--
-- Dumping data for table `settings`
--

INSERT INTO `settings` (`id`, `site_seo`, `site_title`, `site_description`, `site_keywords`, `site_logo`, `site_name`, `site_currency`, `favicon`, `site_language`, `site_theme`, `site_theme_alt`, `recaptcha`, `recaptcha_key`, `recaptcha_secret`, `custom_header`, `custom_footer`, `ticket_system`, `register_page`, `service_speed`, `service_list`, `dolar_charge`, `euro_charge`, `smtp_user`, `smtp_pass`, `smtp_server`, `smtp_port`, `smtp_protocol`, `alert_type`, `alert_newbankpayment`, `alert_newmanuelservice`, `alert_newticket`, `alert_apibalance`, `alert_serviceapialert`, `sms_provider`, `sms_title`, `sms_user`, `sms_pass`, `sms_validate`, `admin_mail`, `admin_telephone`, `resetpass_page`, `resetpass_sms`, `resetpass_email`, `site_maintenance`, `servis_siralama`, `bronz_statu`, `silver_statu`, `gold_statu`, `bayi_statu`, `ns1`, `ns2`, `childpanel_price`) VALUES
(1, 'OSP QuickPanel - SMM Panel', 'OSP QuickPanel - SMM Panel', 'The Best & Cheapest SMM Panel With Quality SMM Services, Cheap SMM Reseller Panel For YouTube SMM Services, Facebook SMM Services, Instagram SMM Services, Get the best SMM Panel today!', 'SMM Panel , OSP QuickPanel - SMM Panel', 'public/images/e46de7e1bcaaced9a54f1e9d0d2f800d.png', 'QuickPanel', 'INR', 'public/images/6fe3dfe314684a658c1b19ca7a8e3abd29afe23e.png', 'en', 'pro', 'Cerulean', '1', '', '', '', '', '2', '2', '1', '2', 74, 76, 'no-reply@socialkart.in', 'ownsmmpanel@#', 'mail.socialkart.in', '465', 'ssl', '2', '1', '1', '1', '1', '1', 'bizimsms', '', '', '', '1', 'info.maliksahab@gmail.com', '8355965199', '2', '1', '1', '2', 'desc', 500, 10000, 30000, 150000, 'ns1.ownsmmpanel.in', 'ns2.ownsmmpanel.in', 599);

-- --------------------------------------------------------

--
-- Table structure for table `themes`
--

CREATE TABLE `themes` (
  `id` int(11) NOT NULL,
  `theme_name` text NOT NULL,
  `theme_dirname` text NOT NULL,
  `theme_extras` text NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

--
-- Dumping data for table `themes`
--

INSERT INTO `themes` (`id`, `theme_name`, `theme_dirname`, `theme_extras`) VALUES
(1, 'Classic', 'bootstrap', ''),
(252, 'Pro', 'pro', '{\"stylesheets\":[\"public/pro/panel/1607327652/bootstrap.css\",\"public/pro/pro/panel/style.css\",\"https:\\/\\/stackpath.bootstrapcdn.com\\/font-awesome\\/4.7.0\\/css\\/font-awesome.min.css\",\"public\\/datepicker\\/css\\/bootstrap-datepicker3.min.css\"],\"scripts\":[\"https:\\/\\/code.jquery.com\\/jquery-3.3.1.min.js\",\"public/pro/script.js\",\"public/ajax.js\",\"public/pro/bootstrap.js\",\"public\\/datepicker\\/js\\/bootstrap-datepicker.min.js\",\"public\\/datepicker\\/locales\\/bootstrap-datepicker.en.min.js\"]}'),
(2, 'pro-blue', 'pro-blue', '{\"stylesheets\":[\"public/darker/bootstrap.css\",\"public/darker/style.css\",\"https:\\/\\/stackpath.bootstrapcdn.com\\/font-awesome\\/4.7.0\\/css\\/font-awesome.min.css\",\"public\\/datepicker\\/css\\/bootstrap-datepicker3.min.css\"],\"scripts\":[\"https:\\/\\/code.jquery.com\\/jquery-3.3.1.min.js\",\"public/darker/script.js\",\"public/ajax.js\",\"public/darker/bootstrap.js\",\"public\\/datepicker\\/js\\/bootstrap-datepicker.min.js\",\"public\\/datepicker\\/locales\\/bootstrap-datepicker.tr.min.js\"]}'),
(3, 'pro-red', 'pro-red', '{\"stylesheets\":[\"public/Agrzm/bootstrap.css\",\"public/Agrzm/style.css\",\"https:\\/\\/stackpath.bootstrapcdn.com\\/font-awesome\\/4.7.0\\/css\\/font-awesome.min.css\",\"public\\/datepicker\\/css\\/bootstrap-datepicker3.min.css\"],\"scripts\":[\"https:\\/\\/code.jquery.com\\/jquery-3.3.1.min.js\",\"public/Agrzm/script.js\",\"public/ajax.js\",\"public/Agrzm/bootstrap.js\",\"public\\/datepicker\\/js\\/bootstrap-datepicker.min.js\",\"public\\/datepicker\\/locales\\/bootstrap-datepicker.tr.min.js\"]}');

-- --------------------------------------------------------

--
-- Table structure for table `tickets`
--

CREATE TABLE `tickets` (
  `ticket_id` int(11) NOT NULL,
  `client_id` int(11) NOT NULL,
  `subject` varchar(225) NOT NULL,
  `time` datetime NOT NULL,
  `lastupdate_time` datetime NOT NULL,
  `client_new` enum('1','2') NOT NULL DEFAULT '2',
  `status` enum('pending','answered','closed') NOT NULL DEFAULT 'pending',
  `support_new` enum('1','2') NOT NULL DEFAULT '1',
  `canmessage` enum('1','2') NOT NULL DEFAULT '2'
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `ticket_reply`
--

CREATE TABLE `ticket_reply` (
  `id` int(11) NOT NULL,
  `ticket_id` int(11) NOT NULL,
  `client_id` int(11) NOT NULL,
  `time` datetime NOT NULL DEFAULT current_timestamp(),
  `support` enum('1','2') NOT NULL DEFAULT '1',
  `message` text NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

--
-- Indexes for dumped tables
--

--
-- Indexes for table `bank_accounts`
--
ALTER TABLE `bank_accounts`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `categories`
--
ALTER TABLE `categories`
  ADD PRIMARY KEY (`category_id`);

--
-- Indexes for table `childpanels`
--
ALTER TABLE `childpanels`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `clients`
--
ALTER TABLE `clients`
  ADD PRIMARY KEY (`client_id`);

--
-- Indexes for table `clients_category`
--
ALTER TABLE `clients_category`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `clients_price`
--
ALTER TABLE `clients_price`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `clients_service`
--
ALTER TABLE `clients_service`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `client_report`
--
ALTER TABLE `client_report`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `kuponlar`
--
ALTER TABLE `kuponlar`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `kupon_kullananlar`
--
ALTER TABLE `kupon_kullananlar`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `languages`
--
ALTER TABLE `languages`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `orders`
--
ALTER TABLE `orders`
  ADD PRIMARY KEY (`order_id`);

--
-- Indexes for table `pages`
--
ALTER TABLE `pages`
  ADD PRIMARY KEY (`page_id`);

--
-- Indexes for table `payments`
--
ALTER TABLE `payments`
  ADD PRIMARY KEY (`payment_id`);

--
-- Indexes for table `payments_bonus`
--
ALTER TABLE `payments_bonus`
  ADD PRIMARY KEY (`bonus_id`);

--
-- Indexes for table `payment_methods`
--
ALTER TABLE `payment_methods`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `serviceapi_alert`
--
ALTER TABLE `serviceapi_alert`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `services`
--
ALTER TABLE `services`
  ADD PRIMARY KEY (`service_id`);

--
-- Indexes for table `service_api`
--
ALTER TABLE `service_api`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `settings`
--
ALTER TABLE `settings`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `themes`
--
ALTER TABLE `themes`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `tickets`
--
ALTER TABLE `tickets`
  ADD PRIMARY KEY (`ticket_id`);

--
-- Indexes for table `ticket_reply`
--
ALTER TABLE `ticket_reply`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `bank_accounts`
--
ALTER TABLE `bank_accounts`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;

--
-- AUTO_INCREMENT for table `categories`
--
ALTER TABLE `categories`
  MODIFY `category_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT for table `childpanels`
--
ALTER TABLE `childpanels`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `clients`
--
ALTER TABLE `clients`
  MODIFY `client_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `clients_category`
--
ALTER TABLE `clients_category`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `clients_price`
--
ALTER TABLE `clients_price`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `clients_service`
--
ALTER TABLE `clients_service`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `client_report`
--
ALTER TABLE `client_report`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `kuponlar`
--
ALTER TABLE `kuponlar`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `kupon_kullananlar`
--
ALTER TABLE `kupon_kullananlar`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `languages`
--
ALTER TABLE `languages`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `orders`
--
ALTER TABLE `orders`
  MODIFY `order_id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `pages`
--
ALTER TABLE `pages`
  MODIFY `page_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=11;

--
-- AUTO_INCREMENT for table `payments`
--
ALTER TABLE `payments`
  MODIFY `payment_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `payments_bonus`
--
ALTER TABLE `payments_bonus`
  MODIFY `bonus_id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `serviceapi_alert`
--
ALTER TABLE `serviceapi_alert`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `services`
--
ALTER TABLE `services`
  MODIFY `service_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=15;

--
-- AUTO_INCREMENT for table `service_api`
--
ALTER TABLE `service_api`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `settings`
--
ALTER TABLE `settings`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `themes`
--
ALTER TABLE `themes`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=253;

--
-- AUTO_INCREMENT for table `tickets`
--
ALTER TABLE `tickets`
  MODIFY `ticket_id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `ticket_reply`
--
ALTER TABLE `ticket_reply`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
