require("dotenv").config();
const express = require("express");
const session = require("express-session");
const SQLiteStore = require("connect-sqlite3")(session);
const Database = require("better-sqlite3");
const bcrypt = require("bcryptjs");
const helmet = require("helmet");
const Razorpay = require("razorpay");
const crypto = require("crypto");
const fs = require("fs");
const path = require("path");

const app = express();
const PORT = Number(process.env.PORT || 3000);
const dataDir = path.join(__dirname, "data");
fs.mkdirSync(dataDir, { recursive: true });
const db = new Database(path.join(dataDir, "panel.sqlite"));
db.pragma("journal_mode = WAL");

db.exec(`
CREATE TABLE IF NOT EXISTS users (
 id INTEGER PRIMARY KEY AUTOINCREMENT,
 name TEXT NOT NULL,
 email TEXT NOT NULL UNIQUE,
 password_hash TEXT NOT NULL,
 role TEXT NOT NULL DEFAULT 'user',
 created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
);
CREATE TABLE IF NOT EXISTS services (
 id INTEGER PRIMARY KEY AUTOINCREMENT,
 platform TEXT NOT NULL,
 name TEXT NOT NULL,
 description TEXT DEFAULT '',
 price_per_1000 REAL NOT NULL,
 min_qty INTEGER NOT NULL DEFAULT 100,
 max_qty INTEGER NOT NULL DEFAULT 100000,
 active INTEGER NOT NULL DEFAULT 1
);
CREATE TABLE IF NOT EXISTS wallets (
 user_id INTEGER PRIMARY KEY,
 balance_paise INTEGER NOT NULL DEFAULT 0
);
CREATE TABLE IF NOT EXISTS wallet_ledger (
 id INTEGER PRIMARY KEY AUTOINCREMENT,
 user_id INTEGER NOT NULL,
 amount_paise INTEGER NOT NULL,
 kind TEXT NOT NULL,
 note TEXT,
 created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
);
CREATE TABLE IF NOT EXISTS orders (
 id INTEGER PRIMARY KEY AUTOINCREMENT,
 user_id INTEGER NOT NULL,
 service_id INTEGER NOT NULL,
 link TEXT NOT NULL,
 quantity INTEGER NOT NULL,
 amount_paise INTEGER NOT NULL,
 status TEXT NOT NULL DEFAULT 'pending',
 created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
);
CREATE TABLE IF NOT EXISTS payments (
 id INTEGER PRIMARY KEY AUTOINCREMENT,
 user_id INTEGER NOT NULL,
 razorpay_order_id TEXT NOT NULL UNIQUE,
 amount_paise INTEGER NOT NULL,
 status TEXT NOT NULL DEFAULT 'created',
 created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
);
CREATE TABLE IF NOT EXISTS tickets (
 id INTEGER PRIMARY KEY AUTOINCREMENT,
 user_id INTEGER NOT NULL,
 subject TEXT NOT NULL,
 message TEXT NOT NULL,
 status TEXT NOT NULL DEFAULT 'open',
 created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
);
`);

const seed = db.prepare("SELECT COUNT(*) AS n FROM services").get().n;
if (!seed) {
  const insert = db.prepare("INSERT INTO services (platform,name,description,price_per_1000,min_qty,max_qty) VALUES (?,?,?,?,?,?)");
  [
    ["Instagram","Instagram content promotion","Only use for accounts and content you own or are authorized to promote.",35,100,10000],
    ["YouTube","YouTube video promotion","Use compliant audience-development and advertising methods.",80,100,10000],
    ["Facebook","Facebook page promotion","Use compliant promotion for pages you manage.",45,100,10000]
  ].forEach(x => insert.run(...x));
}

app.set("trust proxy", 1);
app.use(helmet({ contentSecurityPolicy: false }));
// Razorpay webhook needs the raw request body for signature verification.
app.post("/api/payments/webhook", express.raw({ type: "application/json" }), (req, res) => {
  const secret = process.env.RAZORPAY_WEBHOOK_SECRET;
  const signature = req.headers["x-razorpay-signature"];
  if (!secret || !signature || !Buffer.isBuffer(req.body)) return res.status(400).send("Webhook not configured");
  const expected = crypto.createHmac("sha256", secret).update(req.body).digest("hex");
  if (expected.length !== signature.length || !crypto.timingSafeEqual(Buffer.from(expected), Buffer.from(signature))) {
    return res.status(400).send("Invalid signature");
  }
  let event;
  try { event = JSON.parse(req.body.toString("utf8")); } catch { return res.status(400).send("Invalid JSON"); }
  if (event.event === "payment.captured") {
    const rzpOrderId = event.payload?.payment?.entity?.order_id;
    const payment = db.prepare("SELECT * FROM payments WHERE razorpay_order_id=?").get(rzpOrderId);
    if (payment && payment.status !== "captured") {
      const credit = db.transaction(() => {
        db.prepare("UPDATE payments SET status='captured' WHERE id=?").run(payment.id);
        db.prepare("INSERT OR IGNORE INTO wallets(user_id,balance_paise) VALUES (?,0)").run(payment.user_id);
        db.prepare("UPDATE wallets SET balance_paise=balance_paise+? WHERE user_id=?").run(payment.amount_paise, payment.user_id);
        db.prepare("INSERT INTO wallet_ledger(user_id,amount_paise,kind,note) VALUES (?,?,?,?)")
          .run(payment.user_id, payment.amount_paise, "credit", "Razorpay payment captured");
      });
      credit();
    }
  } else if (event.event === "payment.failed") {
    const rzpOrderId = event.payload?.payment?.entity?.order_id;
    if (rzpOrderId) db.prepare("UPDATE payments SET status='failed' WHERE razorpay_order_id=? AND status='created'").run(rzpOrderId);
  }
  res.json({ received: true });
});
app.use(express.json({ limit: "1mb" }));
app.use(session({
  store: new SQLiteStore({ db: "sessions.sqlite", dir: dataDir }),
  secret: process.env.SESSION_SECRET || "development-only-change-this-secret",
  resave: false,
  saveUninitialized: false,
  cookie: { httpOnly: true, sameSite: "lax", secure: process.env.NODE_ENV === "production", maxAge: 7 * 86400000 }
}));

const userView = u => ({ id: u.id, name: u.name, email: u.email, role: u.role });
function auth(req, res, next) {
  if (!req.session.userId) return res.status(401).json({ error: "Please sign in" });
  req.user = db.prepare("SELECT id,name,email,role FROM users WHERE id=?").get(req.session.userId);
  if (!req.user) return res.status(401).json({ error: "Please sign in" });
  next();
}
function admin(req, res, next) {
  if (req.user.role !== "admin") return res.status(403).json({ error: "Admin only" });
  next();
}
function rupeesToPaise(n) { return Math.round(Number(n) * 100); }

app.post("/api/auth/register", async (req, res) => {
  const { name, email, password } = req.body || {};
  if (!name || !email || !password || String(password).length < 8) return res.status(400).json({ error: "Name, email and password (8+ characters) required" });
  try {
    const hash = await bcrypt.hash(String(password), 12);
    const info = db.prepare("INSERT INTO users(name,email,password_hash) VALUES (?,?,?)").run(String(name).trim(), String(email).trim().toLowerCase(), hash);
    db.prepare("INSERT OR IGNORE INTO wallets(user_id,balance_paise) VALUES (?,0)").run(info.lastInsertRowid);
    req.session.userId = info.lastInsertRowid;
    res.json({ user: userView(db.prepare("SELECT id,name,email,role FROM users WHERE id=?").get(info.lastInsertRowid)) });
  } catch { res.status(409).json({ error: "Email may already be registered" }); }
});
app.post("/api/auth/login", async (req, res) => {
  const { email, password } = req.body || {};
  const u = db.prepare("SELECT * FROM users WHERE email=?").get(String(email || "").trim().toLowerCase());
  if (!u || !(await bcrypt.compare(String(password || ""), u.password_hash))) return res.status(401).json({ error: "Invalid email or password" });
  req.session.userId = u.id;
  res.json({ user: userView(u) });
});
app.post("/api/auth/logout", (req, res) => req.session.destroy(() => res.json({ ok: true })));
app.get("/api/auth/me", auth, (req, res) => res.json({ user: userView(req.user) }));

app.get("/api/services", (req, res) => res.json({ services: db.prepare("SELECT id,platform,name,description,price_per_1000,min_qty,max_qty FROM services WHERE active=1 ORDER BY platform,name").all() }));
app.get("/api/wallet", auth, (req, res) => {
  const w = db.prepare("SELECT balance_paise FROM wallets WHERE user_id=?").get(req.user.id) || { balance_paise: 0 };
  res.json({ balance: w.balance_paise / 100 });
});
app.get("/api/orders", auth, (req, res) => res.json({ orders: db.prepare("SELECT o.*,s.platform,s.name AS service_name FROM orders o JOIN services s ON s.id=o.service_id WHERE o.user_id=? ORDER BY o.id DESC").all(req.user.id) }));
app.post("/api/orders", auth, (req, res) => {
  const { serviceId, link, quantity } = req.body || {};
  const service = db.prepare("SELECT * FROM services WHERE id=? AND active=1").get(Number(serviceId));
  const qty = Number(quantity);
  if (!service || !/^https?:\/\//i.test(String(link || "")) || !Number.isInteger(qty) || qty < service.min_qty || qty > service.max_qty) return res.status(400).json({ error: "Check service, URL and quantity" });
  const amount = Math.ceil(service.price_per_1000 * qty / 1000 * 100);
  const create = db.transaction(() => {
    const wallet = db.prepare("SELECT balance_paise FROM wallets WHERE user_id=?").get(req.user.id);
    if (!wallet || wallet.balance_paise < amount) throw new Error("Insufficient wallet balance");
    db.prepare("UPDATE wallets SET balance_paise=balance_paise-? WHERE user_id=?").run(amount, req.user.id);
    db.prepare("INSERT INTO wallet_ledger(user_id,amount_paise,kind,note) VALUES (?,?,?,?)").run(req.user.id, -amount, "debit", "Order payment");
    const info = db.prepare("INSERT INTO orders(user_id,service_id,link,quantity,amount_paise) VALUES (?,?,?,?,?)").run(req.user.id, service.id, String(link), qty, amount);
    return info.lastInsertRowid;
  });
  try { res.json({ orderId: create(), amount: amount / 100, status: "pending" }); }
  catch (e) { res.status(400).json({ error: e.message }); }
});
app.post("/api/payments/create-order", auth, async (req, res) => {
  const amount = Number(req.body?.amount);
  if (!Number.isFinite(amount) || amount < 100 || amount > 2000) return res.status(400).json({ error: "Add-funds amount must be ₹100–₹2000" });
  if (!process.env.RAZORPAY_KEY_ID || !process.env.RAZORPAY_KEY_SECRET) return res.status(503).json({ error: "Razorpay keys are not configured" });
  try {
    const rzp = new Razorpay({ key_id: process.env.RAZORPAY_KEY_ID, key_secret: process.env.RAZORPAY_KEY_SECRET });
    const paise = rupeesToPaise(amount);
    const order = await rzp.orders.create({ amount: paise, currency: "INR", receipt: `u${req.user.id}-${Date.now()}` });
    db.prepare("INSERT INTO payments(user_id,razorpay_order_id,amount_paise) VALUES (?,?,?)").run(req.user.id, order.id, paise);
    res.json({ orderId: order.id, amount: paise, currency: "INR", keyId: process.env.RAZORPAY_KEY_ID });
  } catch { res.status(502).json({ error: "Could not create payment order" }); }
});
app.post("/api/payments/verify", auth, (req, res) => {
  // This endpoint deliberately does not credit the wallet. Only the signed webhook can do that.
  res.status(400).json({ error: "Wallet credit is confirmed only by Razorpay's signed webhook" });
});
app.post("/api/tickets", auth, (req, res) => {
  const { subject, message } = req.body || {};
  if (!subject || !message) return res.status(400).json({ error: "Subject and message required" });
  const info = db.prepare("INSERT INTO tickets(user_id,subject,message) VALUES (?,?,?)").run(req.user.id, String(subject), String(message));
  res.json({ ticketId: info.lastInsertRowid, status: "open" });
});
app.get("/api/admin/overview", auth, admin, (req, res) => {
  res.json({
    users: db.prepare("SELECT COUNT(*) AS n FROM users").get().n,
    orders: db.prepare("SELECT COUNT(*) AS n FROM orders").get().n,
    tickets: db.prepare("SELECT COUNT(*) AS n FROM tickets WHERE status='open'").get().n
  });
});
app.get("/api/admin/orders", auth, admin, (req, res) => res.json({ orders: db.prepare("SELECT o.*,u.email,s.name AS service_name FROM orders o JOIN users u ON u.id=o.user_id JOIN services s ON s.id=o.service_id ORDER BY o.id DESC LIMIT 200").all() }));
app.patch("/api/admin/orders/:id", auth, admin, (req, res) => {
  const allowed = ["pending","processing","completed","cancelled"];
  if (!allowed.includes(req.body?.status)) return res.status(400).json({ error: "Invalid status" });
  db.prepare("UPDATE orders SET status=? WHERE id=?").run(req.body.status, Number(req.params.id));
  res.json({ ok: true });
});
app.get("/api/admin/services", auth, admin, (req, res) => res.json({ services: db.prepare("SELECT * FROM services ORDER BY id DESC").all() }));
app.post("/api/admin/services", auth, admin, (req, res) => {
  const { platform, name, description = "", price_per_1000, min_qty = 100, max_qty = 100000 } = req.body || {};
  if (!platform || !name || !Number.isFinite(Number(price_per_1000)) || Number(price_per_1000) < 0) return res.status(400).json({ error: "Invalid service fields" });
  const info = db.prepare("INSERT INTO services(platform,name,description,price_per_1000,min_qty,max_qty) VALUES (?,?,?,?,?,?)").run(platform,name,description,Number(price_per_1000),Number(min_qty),Number(max_qty));
  res.json({ id: info.lastInsertRowid });
});

app.use(express.static(path.join(__dirname, "public")));
app.get("*", (req, res) => res.sendFile(path.join(__dirname, "public", "index.html")));

const adminEmail = process.env.ADMIN_EMAIL;
const adminPassword = process.env.ADMIN_PASSWORD;
if (adminEmail && adminPassword) {
  const exists = db.prepare("SELECT id FROM users WHERE email=?").get(adminEmail.toLowerCase());
  if (!exists) {
    const hash = bcrypt.hashSync(adminPassword, 12);
    const info = db.prepare("INSERT INTO users(name,email,password_hash,role) VALUES (?,?,?,'admin')").run("Administrator", adminEmail.toLowerCase(), hash);
    db.prepare("INSERT OR IGNORE INTO wallets(user_id,balance_paise) VALUES (?,0)").run(info.lastInsertRowid);
  }
}
app.listen(PORT, () => console.log(`Panel running on port ${PORT}`));
